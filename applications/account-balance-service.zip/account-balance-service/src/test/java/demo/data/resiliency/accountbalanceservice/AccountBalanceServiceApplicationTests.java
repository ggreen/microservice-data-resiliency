package demo.data.resiliency.accountbalanceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountBalanceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
